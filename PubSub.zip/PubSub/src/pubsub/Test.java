package pubsub;

import pubsub.channel.Channel;
import pubsub.publisher.Publisher;
import pubsub.subscriber.Subscriber;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Publisher universityEn = new Publisher();
		Publisher universityFr = new Publisher();

		Subscriber studentEn = new Subscriber();
		Subscriber studentFrEn = new Subscriber();
		Subscriber studentFr = new Subscriber();

		Channel channel = new Channel();

		Message frMessage1 = new Message("Fr", "Bienvenue");
		Message frMessage2 = new Message("Fr", "Bonjour");
		Message frMessage3 = new Message("Fr", "Au revoir");

		universityFr.publish(frMessage1, channel);
		universityFr.publish(frMessage2, channel);
		universityFr.publish(frMessage3, channel);

		Message enMessage1 = new Message("En", "Welcome");
		Message enMessage2 = new Message("En", "Hello");
		Message enMessage3 = new Message("En", "Good bye");

		universityEn.publish(enMessage1, channel);
		universityEn.publish(enMessage2, channel);
		universityEn.publish(enMessage3, channel);

		studentFr.addSub("Fr", channel);
		studentEn.addSub("En", channel);
		studentFrEn.addSub("Fr", channel);
		studentFrEn.addSub("En", channel);

		channel.broadcast();

		System.out.println("French messages : ");
		studentFr.printMessages();

		System.out.println("\nEnglish messages : ");
		studentEn.printMessages();

		System.out.println("\nAll languages messages : ");
		studentFrEn.printMessages();

		Message frMessage4 = new Message("Fr", "Comment allez vous ?");
		Message frMessage5 = new Message("Fr", "Tout ce passe bien ?");

		universityFr.publish(frMessage4, channel);
		universityFr.publish(frMessage5, channel);

		studentFr.getSubMessages("Fr", channel);
		System.out.println("\n\nAll Fr Messages : ");
		studentFr.printMessages();
		

	}

}
