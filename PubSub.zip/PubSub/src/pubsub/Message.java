package pubsub;

public class Message {

	private String topic; // The name of the topic
	private String data; // The message

	public Message() {
	}

	public Message(String topic, String data) {
		this.topic = topic;
		this.data = data;
	}

	public String getTopic() {
		return this.topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getData() {
		return this.data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
