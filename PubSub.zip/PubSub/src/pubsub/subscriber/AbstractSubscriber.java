package pubsub.subscriber;

import java.util.ArrayList;
import java.util.List;

import pubsub.Message;
import pubsub.channel.Channel;

public abstract class AbstractSubscriber {
	// List of all message received by a sub
	private List<Message> subMessages = new ArrayList<Message>();

	public List<Message> getSubMessages() {
		return this.subMessages;
	}

	public void setSubMessages(List<Message> subMessages) {
		this.subMessages = subMessages;
	}

	// add a sub to a topic with channel
	public abstract void addSub(String topic, Channel channel);

	// remove a sub of a topic with channel
	public abstract void unSub(String topic, Channel channel);

	// All messages from a same topic
	public abstract void getSubMessages(String topic, Channel channel);

	// print new messages received by a sub
	public void printMessages() {
		for (Message message : subMessages) {
			System.out.println("Message of " + message.getTopic() + " : " + message.getData());
		}
	}
}
