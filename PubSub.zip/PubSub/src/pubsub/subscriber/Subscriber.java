package pubsub.subscriber;

import pubsub.channel.Channel;

public class Subscriber extends AbstractSubscriber {

	@Override
	public void addSub(String topic, Channel channel) {
		channel.addSub(topic, this);

	}

	@Override
	public void unSub(String topic, Channel channel) {
		channel.DeleteSub(topic, this);

	}

	@Override
	public void getSubMessages(String topic, Channel channel) {
		channel.getMessagesForSubOfTopic(topic, this);

	}

}
