package pubsub.channel;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import pubsub.Message;
import pubsub.subscriber.Subscriber;

public class Channel {

	// Dictionary of subscribers of a topic
	// We use Set to have a collection of no duplicate elements
	private Map<String, Set<Subscriber>> subTopicDictionary = new HashMap<String, Set<Subscriber>>();

	// A queue of message publish a publisher
	private Queue<Message> queueOfMessage = new LinkedList<Message>();

	// Add a message to the queue
	public void addMessageToQueue(Message message) {
		queueOfMessage.add(message);
	}

	// Add a new subscriber to a topic
	public void addSub(String topic, Subscriber sub) {

		if (subTopicDictionary.containsKey(topic)) {
			Set<Subscriber> subs = subTopicDictionary.get(topic);
			subs.add(sub);
			subTopicDictionary.put(topic, subs);
		} else {
			Set<Subscriber> subs = new HashSet<Subscriber>();
			subs.add(sub);
			subTopicDictionary.put(topic, subs);
		}
	}

	// Remove a sub of a topic
	public void DeleteSub(String topic, Subscriber sub) {

		if (subTopicDictionary.containsKey(topic)) {
			Set<Subscriber> subs = subTopicDictionary.get(topic);
			subs.remove(sub);
			subTopicDictionary.put(topic, subs);
		}
	}

	// Broadcast new message to all sub of a topic
	public void broadcast() {
		if (queueOfMessage.isEmpty()) {
			System.out.println("There are no new messages");
		} else {
			while (!queueOfMessage.isEmpty()) {
				Message message = queueOfMessage.remove();

				String topic = message.getTopic();

				Set<Subscriber> subsOfTopic = subTopicDictionary.get(topic);

				for (Subscriber sub : subsOfTopic) {
					List<Message> subMessage = sub.getSubMessages();
					subMessage.add(message);
					sub.setSubMessages(subMessage);
				}
			}
		}
	}

	// send all messages of a topic to one sub
	public void getMessagesForSubOfTopic(String topic, Subscriber subscriber) {
		if (queueOfMessage.isEmpty()) {
			System.out.println("No messages from publishers to display");
		} else {
			while (!queueOfMessage.isEmpty()) {
				Message message = queueOfMessage.remove();

				if (message.getTopic().equalsIgnoreCase(topic)) {

					Set<Subscriber> subscribersOfTopic = subTopicDictionary.get(topic);

					for (Subscriber _subscriber : subscribersOfTopic) {
						if (_subscriber.equals(subscriber)) {
							// add broadcasted message to subscriber message queue
							List<Message> subscriberMessages = subscriber.getSubMessages();
							subscriberMessages.add(message);
							subscriber.setSubMessages(subscriberMessages);
						}
					}
				}
			}
		}
	}
}
