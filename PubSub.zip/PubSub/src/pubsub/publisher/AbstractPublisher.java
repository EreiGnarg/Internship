package pubsub.publisher;

import pubsub.Message;
import pubsub.channel.Channel;

public abstract class AbstractPublisher {

	// Permits to publish a new message to the server
	public abstract void publish(Message message, Channel channel);

}
