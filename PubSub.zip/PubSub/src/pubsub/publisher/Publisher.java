package pubsub.publisher;

import pubsub.Message;
import pubsub.channel.Channel;

public class Publisher extends AbstractPublisher {

	// Permits to publish a new message to the server
	public void publish(Message message, Channel channel) {
		channel.addMessageToQueue(message);
	}

}
